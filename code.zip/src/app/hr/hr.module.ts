import { RouterModule } from '@angular/router';
import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicesComponent } from './services/services.component';

const links = [
  {
     path: '',
     Component: ServicesComponent
  }
];


@NgModule({
  declarations: [ServicesComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(links)
  ],
  exports:[ ServicesComponent ]
})
export class HRModule {
  constructor (){
    console.log('Hi in hr module constructor');
  }
 }
