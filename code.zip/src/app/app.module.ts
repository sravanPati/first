import { StaffModule } from './staff/staff.module';
import { ContactModule } from './contact/contact.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ToysComponent } from './toys/toys.component';
import { DetailsComponent } from './details/details.component';
import { EditdataComponent } from './editdata/editdata.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ToysComponent,
    DetailsComponent,
    EditdataComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    ContactModule,
    StaffModule,


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
