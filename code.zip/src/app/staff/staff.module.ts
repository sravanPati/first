

import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ServicesComponent } from './services/services.component';

import { StaffdasComponent } from './staffdas/staffdas.component';

const linkme = [
  {path: 'staffdas',
  component: StaffdasComponent,
  children: [{
    path: 'staffservices',
    component: ServicesComponent
  }]
  },
];

@NgModule({
  declarations: [ServicesComponent, StaffdasComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(linkme)
  ]
})
export class StaffModule { }

