import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffdas',
  templateUrl: './staffdas.component.html',
  styleUrls: ['./staffdas.component.css']
})


export class StaffdasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
