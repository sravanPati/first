import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StaffdasComponent } from './staffdas.component';

describe('StaffdasComponent', () => {
  let component: StaffdasComponent;
  let fixture: ComponentFixture<StaffdasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StaffdasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StaffdasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
