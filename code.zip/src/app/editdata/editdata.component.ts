import { CheckService } from './../check.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editdata',
  templateUrl: './editdata.component.html',
  styleUrls: ['./editdata.component.css']
})
export class EditdataComponent implements OnInit {

  constructor(private recievedata:CheckService) { }

  recievedData;
  gotdata;
  ngOnInit() {
    this.recievedata.getDataEdit().subscribe(
      res=>{console.log(res);
        this.recievedData=res;
      });
  }

  edit(d){

    this.gotdata=d;
  }
  delete(d){
    console.log(d);
    // this.recievedata.;
}
}
