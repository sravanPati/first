import { CheckService } from './../check.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  
  constructor(private fb: FormBuilder,private checkSer:CheckService) { }

  profileForm = this.fb.group({
    name: [''],
    password: ['']});
    login_data;
  ngOnInit() {
  }
  submit(){
    console.log(this.profileForm.value);
    this.login_data = this.checkSer.getdata();
    this.checkSer.postdata(this.profileForm.value);

  }

     






} 






