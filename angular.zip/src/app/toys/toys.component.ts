import { CheckService } from './../check.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toys',
  templateUrl: './toys.component.html',
  styleUrls: ['./toys.component.css']
})
export class ToysComponent implements OnInit {

  constructor(private dataServ:CheckService) { }


  photos:object;

  
  ngOnInit() {
    this.dataServ.geturl().subscribe(res=> {
      console.log(res);
      this.photos=res;
    } )
  }

}
