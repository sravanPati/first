import { DetailsComponent } from './details/details.component';
import { ToysComponent } from './toys/toys.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { EditdataComponent } from './editdata/editdata.component';


const routes: Routes = [
                        {
                          path:"home",
                          component:HomeComponent,
                          children:[
                            {
                              path:"toys",
                              component:ToysComponent
                            },
                            {
                              path:"editdata",
                              component:EditdataComponent

                            },
                            {
                              path:"details/:myid",
                              component:DetailsComponent
                            }
                          ]
                      },
                       
                      ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { } 
// const routes: Routes = [{
//   path: '',
//   component: DashBoardComponent,
//   children: [
//    {
//       path: '',
//       redirectTo: 'home',
//       pathMatch: 'prefix'
//    },
//    {
//       path: 'home',
//       component: HomeComponent
//    }
//  ]
// }];