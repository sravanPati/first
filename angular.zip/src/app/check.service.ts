import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CheckService {
 myurl="http://localhost:3000/posts";
 datasend="https://jsonplaceholder.typicode.com/posts";
  constructor(private checkIt:HttpClient) { }

  getdata(){
    this.checkIt.get(this.myurl);
  }
  postdata(b){
    this.checkIt.post(this.myurl,b);
  }

  myURL="https://jsonplaceholder.typicode.com/photos";



  geturl(){
   return this.checkIt.get(this.myURL);
  }
  getDataEdit(){
    return this.checkIt.get(this.datasend);
  }
}
